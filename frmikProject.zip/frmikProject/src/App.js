import React from "react";
// import SignUp from "./SignUp";
import Registration from "./Registration";

const App = () => {
  // return <SignUp />;
  return <Registration />;
};

export default App;